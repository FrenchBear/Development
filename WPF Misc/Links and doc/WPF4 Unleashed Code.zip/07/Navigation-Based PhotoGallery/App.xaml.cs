using System.Windows;

namespace PhotoGallery
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
        }
    }
}