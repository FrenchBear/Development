using System;
using System.Windows;

namespace HostingWindowsFormsControl
{
    /// <summary>
    /// Interaction logic for MyApp.xaml
    /// </summary>

    public partial class MyApp : Application
    {

    }
}