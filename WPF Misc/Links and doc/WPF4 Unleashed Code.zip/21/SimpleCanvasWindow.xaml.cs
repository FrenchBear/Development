﻿using System.Windows;

namespace CustomPanels
{
    public partial class SimpleCanvasWindow : Window
    {
        public SimpleCanvasWindow()
        {
            InitializeComponent();
        }
    }
}
