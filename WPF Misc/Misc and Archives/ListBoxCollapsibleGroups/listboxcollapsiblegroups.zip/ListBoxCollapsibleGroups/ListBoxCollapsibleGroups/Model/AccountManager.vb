﻿
Public Class AccountManager

#Region " Declarations "
    Private _dblSales As Double

    Private _strFirstName As String = String.Empty
    Private _strLastName As String = String.Empty
    Private _strRegion As String = String.Empty
    Private _strState As String = String.Empty

#End Region

#Region " Properties "

    Public ReadOnly Property FirstName() As String
        Get
            Return _strFirstName
        End Get
    End Property

    Public ReadOnly Property FullName() As String
        Get
            Return Trim(String.Format("{0} {1}", _strFirstName, _strLastName))
        End Get
    End Property

    Public ReadOnly Property LastName() As String
        Get
            Return _strLastName
        End Get
    End Property

    Public ReadOnly Property Region() As String
        Get
            Return _strRegion
        End Get
    End Property

    Public ReadOnly Property Sales() As Double
        Get
            Return _dblSales
        End Get
    End Property

    Public ReadOnly Property State() As String
        Get
            Return _strState
        End Get
    End Property

#End Region

#Region " Constructor "

    Public Sub New(ByVal strFirstName As String, ByVal strLastName As String, ByVal strRegion As String, ByVal strState As String, ByVal dblSales As Double)
        _strFirstName = strFirstName
        _strLastName = strLastName
        _strRegion = strRegion
        _strState = strState
        _dblSales = dblSales
    End Sub

#End Region

End Class
