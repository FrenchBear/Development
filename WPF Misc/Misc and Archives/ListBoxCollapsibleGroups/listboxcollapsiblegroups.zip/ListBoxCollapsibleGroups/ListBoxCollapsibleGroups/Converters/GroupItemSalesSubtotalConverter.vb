﻿Imports System.Windows.Data
<ValueConversion(GetType(CollectionViewGroup), GetType(Double))> Public Class GroupItemSalesSubtotalConverter
    Implements IValueConverter

    Public Function Convert(ByVal value As Object, ByVal targetType As System.Type, ByVal parameter As Object, ByVal culture As System.Globalization.CultureInfo) As Object Implements System.Windows.Data.IValueConverter.Convert

        If value IsNot Nothing AndAlso TypeOf value Is CollectionViewGroup Then
            Return GetSubTotal(DirectCast(value, CollectionViewGroup))

        Else
            Return Nothing
        End If

    End Function

    Public Function ConvertBack(ByVal value As Object, ByVal targetType As System.Type, ByVal parameter As Object, ByVal culture As System.Globalization.CultureInfo) As Object Implements System.Windows.Data.IValueConverter.ConvertBack
        Throw New NotImplementedException
    End Function

    Private Function GetSubTotal(ByVal obj As CollectionViewGroup) As Double

        Dim dbl As Double

        For Each objItem As Object In obj.Items

            If TypeOf objItem Is AccountManager Then
                dbl += DirectCast(objItem, AccountManager).Sales

            Else
                dbl += GetSubTotal(objItem)
            End If

        Next

        Return dbl
    End Function

End Class
