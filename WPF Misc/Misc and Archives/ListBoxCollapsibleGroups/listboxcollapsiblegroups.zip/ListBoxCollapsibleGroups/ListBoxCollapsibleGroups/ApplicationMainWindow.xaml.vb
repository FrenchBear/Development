﻿Partial Public Class ApplicationMainWindow
End Class
