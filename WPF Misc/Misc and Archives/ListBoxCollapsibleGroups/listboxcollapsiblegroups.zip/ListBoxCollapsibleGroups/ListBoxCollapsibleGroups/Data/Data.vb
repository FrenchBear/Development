﻿
Public Class Data

    Public Shared ReadOnly Property AccountManagers() As List(Of AccountManager)
        Get

            If _objAccountManagers Is Nothing Then
                _objAccountManagers = GetAccountManagers()
            End If

            Return _objAccountManagers
        End Get
    End Property

    Private Shared _objAccountManagers As List(Of AccountManager)

    Private Shared Function GetAccountManagers() As List(Of AccountManager)
        _objAccountManagers = New List(Of AccountManager)
        With _objAccountManagers
            .Add(New AccountManager("Albert", "Pencil", "North East", "NY", 1259847))
            .Add(New AccountManager("Ben", "Paper", "North East", "NY", 1059000))
            .Add(New AccountManager("Charlie", "Pen", "North East", "NY", 1523500))
            .Add(New AccountManager("Debbie", "Stapler", "North East", "NY", 1698750))
            .Add(New AccountManager("Efrim", "Inspector", "North East", "NJ", 1253700))
            .Add(New AccountManager("Frank", "Vision", "North East", "NJ", 1257690))
            .Add(New AccountManager("George", "Jungle", "North East", "NJ", 925740))
            .Add(New AccountManager("Harry", "Sailor", "North East", "NJ", 1115220))
            .Add(New AccountManager("Iris", "Green", "North East", "NJ", 1496357))
            .Add(New AccountManager("Josh", "JJSmooth", "West", "WA", 1765877))
            .Add(New AccountManager("Karl", "Molenator", "West", "WA", 1765877))
            .Add(New AccountManager("Larry", "Lied", "West", "WA", 1600000))
            .Add(New AccountManager("Matt", "Thriller", "West", "WA", 1488690))
            .Add(New AccountManager("No", "Way", "West", "WA", 1925500))
            .Add(New AccountManager("Open", "Season", "West", "WA", 1111000))
            .Add(New AccountManager("Perfect", "Shot", "West", "HI", 825000))
            .Add(New AccountManager("Quick", "Draw", "West", "HI", 950000))
            .Add(New AccountManager("Rank", "Smell", "West", "HI", 795599))
            .Add(New AccountManager("Top", "Secret", "West", "WA", 1368477))
        End With
        Return _objAccountManagers
    End Function

End Class
