namespace CustomControls.Data
{
	public interface IAddNew
	{
		bool AddNew { get; }
	}
}
