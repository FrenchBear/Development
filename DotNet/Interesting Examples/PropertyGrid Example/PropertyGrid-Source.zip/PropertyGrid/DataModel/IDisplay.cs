namespace DataModel
{
	public interface IDisplay
	{
		string Text { get; }
	}
}
