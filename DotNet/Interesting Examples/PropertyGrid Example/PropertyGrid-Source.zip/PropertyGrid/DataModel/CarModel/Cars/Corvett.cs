using DataModel.CarModel.Cars;

namespace DataModel.CarModel.Cars
{
	public class Corvett : Car
	{
	}
}