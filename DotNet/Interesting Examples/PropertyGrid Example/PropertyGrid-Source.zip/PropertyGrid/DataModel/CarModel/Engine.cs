namespace DataModel.CarModel
{
	public enum Engine
	{
		TwoCylinder,
		FourCylinder,
		V8
	}
}