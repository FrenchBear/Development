namespace DomainModel
{
	public enum Engine
	{
		TwoCylinder,
		FourCylinder,
		V8
	}
}