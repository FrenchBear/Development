namespace DomainModel
{
	public enum BodyStyle
	{
		Convertible,
		Coupe,
		Hybrid,
		Luxury,
		MiniVan,
		TwoDoor,
		Sedan,
		SUV,
		Truck,
		Van,
		Wagon
	}
}