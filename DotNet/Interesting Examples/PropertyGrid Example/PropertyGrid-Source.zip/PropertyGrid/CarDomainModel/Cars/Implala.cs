namespace DomainModel.Cars
{
	public class Implala : Car
	{
	}
}
