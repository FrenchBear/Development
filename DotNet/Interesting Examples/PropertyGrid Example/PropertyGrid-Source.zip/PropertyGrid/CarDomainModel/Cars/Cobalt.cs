namespace DomainModel.Cars
{
	public class Cobalt : Car
	{
	}
}
