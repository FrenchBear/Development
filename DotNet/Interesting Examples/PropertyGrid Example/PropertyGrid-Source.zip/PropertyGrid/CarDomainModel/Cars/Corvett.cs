namespace DomainModel.Cars
{
	public class Corvett : Car
	{
	}
}
