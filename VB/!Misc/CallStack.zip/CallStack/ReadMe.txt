Black Belt column
by Dan Fergus
Visual Studio Magazine, May 2002

This zip include the files required to build the StackTrace class.  Form1 is a simple form to show how the class is used.

Inlcuded also is the program PrivateStrip.exe that can be used to strip private information from the PDB file before you send it to a customer. You can get the full source code for this program from the Wintellect website (see resources)

Be sure to update the location of the VBoostTypes6.olb reference in the project when you load this application to test the sample code.