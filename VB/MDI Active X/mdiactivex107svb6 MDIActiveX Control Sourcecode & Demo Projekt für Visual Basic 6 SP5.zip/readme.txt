*-------------------------------------------------------------------*
* 				                                    *
* MDIActiveX.ocx Version 1.0.7 for Visual Basic 6/sp5               *
* 								    *
* There is a demo project in the directory DEMO                     *
*                                                                   *
* ----------------------------------------------------------------- *
*                                                                   *
* Autor:	Michael Wallner                                     *
* Datum:        August 2001                                         *
* WEB:          www.wallner-software.com                            *
* eMail:        mdiativex@wallner-software.com                      *
*                                                                   *
* ----------------------------------------------------------------- *


The file mdiactivex107svb6.zip contains the source of the MDIActiveX6 control and
a demo project.

The MDIActiveX control is freeware!
You are allowed to use it in your (commercial) projects!

Please send me an email if you are going to use my control!

If you use the MDIActiveX control in a commercial project then give some credit!
(like a message in the INFO dialog 'create with the MDIActiveX control by
Michael Wallner  http://www.wallner-software.com')

Vienna Nov. 2000/Aug. 2001
