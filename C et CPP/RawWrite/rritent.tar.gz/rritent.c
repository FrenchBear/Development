/*
    RawRiteNT
	For "raw writing" images to a floppy disk under Windows NT
	I wrote this because RAWRITE 13 doesn't work under NT.
	(I think 2.0 does, but it doesn't write reliable images).

  NOTE:  I borrowed/modified some source from the original rawrite :)
         The only difference the user should notice is that:
			This will only work under NT;
			You must pass all options at the command line (I'm too lazy to
			  do it like he did)


  Released under the GPL.
  See License.txt for more information.

  */

#define WIN32_LEAN_AND_MEAN /* don't include extra headers, we'll do any extra ones we need */
#include <windows.h>
#include <winioctl.h>
#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>

void usage(char * progname)
{
	fprintf(stderr, "\nusage: %s <file name> <letter:>\n", progname);
	exit(-1);
}

char * GetLastErrorString(void)
{
	LPVOID lpMsgBuf;

	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR) &lpMsgBuf,	0, NULL);
	
	return (char *)lpMsgBuf;
}

void main(int argc, char *argv[])
{

	OSVERSIONINFO os_ver_info;
	char image_file[MAX_PATH];
	char drv_letter[1];
	char drv_dev_name[5];
	HANDLE hDrive;
	char * buffer;
	int count, fd_img, img_len, bs_written = 0, sect, sects, sectsize;
	float percent = 0;
	DISK_GEOMETRY dg_flop_geom;
	DWORD dwNotUsed;
	DWORD dwBsWritten;

	/* Make sure we're running NT... */
	os_ver_info.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);

	if (GetVersionEx(&os_ver_info)) {
		if (os_ver_info.dwPlatformId != VER_PLATFORM_WIN32_NT) {
			fprintf(stderr, "\nRawRiteNT only works on Windows NT.  Please try the original \
				RawRite\n");
			exit(-1);
		}
	} else {
		fprintf(stderr, "\nGetVersionEx failed! Continuing anyway...  Error %s\n", GetLastErrorString());
	}


	/* parse arguments */
	if (argc != 3) {
		usage(argv[0]);
	}

	if (strlen(argv[1]) > 1 && strlen(argv[1]) < 255) {
		strcpy(image_file, argv[1]);
	} else {
		fprintf(stderr, "\nImage file name too long or too short (make sure it's \
				less then 254 characters and greater then 1 character)\n");
		exit(-1);
	}

	if (strlen(argv[2]) == 2) {
		strcpy(drv_letter, argv[2]);
		toupper(drv_letter[0]);
	} else {
		fprintf(stderr, "\nInvalid drive \'%s\' (make sure you have \'%s:\' not \'%s\')\n", argv[2], argv[2], argv[2]);
		exit(-1);
	}


	/* Open the disk for raw access:
		Read http://support.microsoft.com/support/kb/articles/Q100/0/27.asp for more info
	*/
	sprintf(drv_dev_name, "\\\\.\\%s", drv_letter);
	
	hDrive = CreateFile(drv_dev_name, GENERIC_WRITE,
						FILE_SHARE_READ|FILE_SHARE_WRITE,
						NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL,
						NULL);
	if (hDrive == INVALID_HANDLE_VALUE) {
		fprintf(stderr, "\nError: %s\n", GetLastErrorString());
		CloseHandle(hDrive);
		exit(-1);
	}

	/* open file to write to disk */
	if ((fd_img = _open(image_file, _O_RDONLY | _O_BINARY)) == -1 ) {
		perror(image_file);
		exit(-1);
	}

	/* get the length of it so we can give them a percent of how much time left */
	img_len = _filelength(fd_img);

	/* get information about the sector/track/cylinder size etc... */
	if(DeviceIoControl(hDrive, IOCTL_DISK_GET_DRIVE_GEOMETRY, NULL,
						0, &dg_flop_geom, sizeof(dg_flop_geom),
						&dwNotUsed, NULL) == FALSE) {

		fprintf(stderr, "\nCouldn't get drive geometry (DeviceIoControl returned \
				FALSE), exiting.  Error: %s\n", GetLastErrorString());
		CloseHandle(hDrive);
		exit(-1);

	}


	if ((dg_flop_geom.MediaType == FixedMedia) | (dg_flop_geom.MediaType == RemovableMedia) |
		(dg_flop_geom.MediaType == Unknown) | (dg_flop_geom.MediaType == F5_320_1024)) {
		printf("Will not write to drive %s.  It is either: fixed media, unknown media\n", drv_letter);
		puts("unknown removable media, it's sector size isn't 512 bytes.");
		puts("RawriteNT is only for floppies with sector sizes of 512 bytes (most floppies).");
		CloseHandle(hDrive);
		exit (-1);
	}

	sects = dg_flop_geom.SectorsPerTrack;
	sectsize = dg_flop_geom.BytesPerSector;
	sect = 0;
	buffer = (char *)malloc(sectsize);
	if (SetFilePointer(hDrive, 0, NULL, FILE_BEGIN) == -1) {
		fprintf(stderr, "SetFilePointer failed, Error: %s", GetLastErrorString());
		exit(-1);
	}

	printf("Writing image file to drive %s. Press ^C to abort.\n", drv_letter);
	while ((count = _read(fd_img, buffer, sectsize)) > 0) {
		bs_written += count;
		percent = (float)bs_written / img_len;
		percent = percent * 100;
		printf("%d percent done\r", (int)percent);
		if (SetFilePointer(hDrive, sect * sectsize, NULL, FILE_BEGIN) == -1) {
			fprintf(stderr, "SetFilePointer failed, Error: %s", GetLastErrorString());
			exit(-1);
		}
		if (WriteFile(hDrive, buffer, sectsize, &dwBsWritten, NULL) == 0) {
			fprintf(stderr, "\nCould not write to drive. Error: %s\n", GetLastErrorString());
			exit (-1);
		}
		sect++;
	}
	puts("\nDone.");

	free(buffer);

	CloseHandle(hDrive);

	exit(0);
}

