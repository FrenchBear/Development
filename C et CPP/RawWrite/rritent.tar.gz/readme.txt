RaWriteNT - RaWrite for Windows NT

I wanted to make a Linux bootdisk under Windows NT and realized that RaWrite didn't work on NT..  Hence I wrote this program.  Released under the GPL.  I havn't had any problems with it but use at your own risk.  Hope this helps out.
Note: although this does the same thing as RaWrite, it's usage isn't exactly the same.


Usage:
rawritent <file> <drive:>

Example:
C:\Slackware\bootdsks.144> rawritent bare.i a:



Dan
cppace@earthlink.net